﻿namespace SWEN_Delonix_Regia_HMS {
    
    
    public partial class JunJieDBDataSet {
    }
}

