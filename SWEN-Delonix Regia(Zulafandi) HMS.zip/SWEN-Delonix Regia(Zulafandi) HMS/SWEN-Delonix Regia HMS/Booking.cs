﻿using SWEN_Delonix_Regia_HMS.managers;
using SWEN_Delonix_Regia_HMS.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SWEN_Delonix_Regia_HMS
{
    public partial class Booking : Form
    {
        int currentGuestID = -1;
        Room selectedRoom = new Room();
        List<HitBox> hitboxes = new List<HitBox>();
        JunJieDBDataSet.GetRoomOccupancyDataTable dt = new JunJieDBDataSet.GetRoomOccupancyDataTable();
        public Booking()
        {
            InitializeComponent();
            this.Size = MasterControl.formSize;
            this.MinimizeBox = MasterControl.showMinimizeBox;
            this.MaximizeBox = MasterControl.showMaximizeBox;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(tbGuestID.Text.Equals(String.Empty)){
                MessageBox.Show("Please input existing booking Id!", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error); //Prompt the user that the Guest ID textbox requires data
                return; //Exit from this click event
            }
            try
            {
            int guestId = Convert.ToInt32(tbGuestID.Text);
                List<Guest> guestList = new DBManager().GetGuestById(guestId);
                Guest myGuest = guestList[0];
                tbFirstName.Text = myGuest.firstName;
                tbLastName.Text = myGuest.lastName;
                tbPhoneNum.Text = Convert.ToString(myGuest.phoneNum);
                tbEmail.Text = myGuest.email;
                tbAddress.Text = myGuest.guestAddress;
                tbCountry.Text = myGuest.country;
                currentGuestID = myGuest.guestId;
            }
            catch (FormatException)
            {
                MessageBox.Show("Please insert numbers only for the guest ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception)
            {
                MessageBox.Show("There are no Booking ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DBManager manager = new DBManager();
            manager.UpdateGuest(currentGuestID, tbFirstName.Text, tbLastName.Text, Convert.ToInt32(tbPhoneNum.Text), tbEmail.Text, tbAddress.Text, tbCountry.Text);
            MessageBox.Show("Details have been saved!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DBManager manager = new DBManager();
            int guestID = manager.InsertGuest(tbFirstName.Text, tbLastName.Text, Convert.ToInt32(tbPhoneNum.Text), tbEmail.Text, tbAddress.Text, tbCountry.Text);
            MessageBox.Show("Details have been created!", "Success!",MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            tbGuestID.Text = guestID.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Main page = new Main();
            this.Hide();
            page.Show(this);//return to main menu
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void Booking_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'Dataset.GetRoomsByHeader' table. You can move, or remove it, as needed.
            this.getRoomsByHeaderTableAdapter.Fill(this.Dataset.GetRoomsByHeader);
            // TODO: This line of code loads data into the 'Dataset.Room' table. You can move, or remove it, as needed.
            this.roomTableAdapter.Fill(this.Dataset.Room);

        }
        

        private void Booking_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            Environment.Exit(0);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            new DBManager().DeleteStaff(Convert.ToInt32(tbGuestID.Text));
            MessageBox.Show("Successfully delete booking");
        }

        private void tbGuestID_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            new DBManager().DeleteStaff(Convert.ToInt32(tbGuestID.Text)); 
            MessageBox.Show("Successfully delete booking");
        }

       
    }
}
