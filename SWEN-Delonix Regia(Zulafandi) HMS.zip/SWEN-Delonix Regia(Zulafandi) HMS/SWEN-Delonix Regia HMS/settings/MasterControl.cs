﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SWEN_Delonix_Regia_HMS
{
    static class MasterControl
    {

        public static Size formSize = new Size(1280, 720); // You can set this to anything. Width and height 
        public static bool showMaximizeBox = true, showMinimizeBox = true;

    }
}
