﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SWEN_Delonix_Regia_HMS.model
{
    class Room
    {
        public int roomId { get; set; }
        public string roomType { get; set; }
        public decimal roomPrice { get; set; }
        public string roomHeader { get; set; }
        public string roomNumber { get; set; }
        public string roomStatus { get; set; }        
    }
}
