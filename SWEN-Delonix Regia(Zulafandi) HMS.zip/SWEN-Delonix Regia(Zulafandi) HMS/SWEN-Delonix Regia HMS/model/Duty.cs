﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SWEN_Delonix_Regia_HMS.model
{
    class Duty
    {
        public int dutyId { get; set; }
        public string dutyType { get; set; }
    }
}
