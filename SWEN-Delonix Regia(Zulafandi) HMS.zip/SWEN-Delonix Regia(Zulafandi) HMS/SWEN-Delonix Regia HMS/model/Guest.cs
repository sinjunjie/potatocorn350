﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SWEN_Delonix_Regia_HMS.model
{
    class Guest
    {
        public int guestId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string guestAddress { get; set; }
        public int phoneNum { get; set; }
        public string country { get; set; }
        public int NumberOfChildren { get; set; }
    }
}
